
import streamlit as st
import pandas as pd
import os
from datetime import datetime

@st.cache_data
def load_data():
    df = pd.read_csv("data/sample_data.csv")
    return df.sample(10, random_state=None).reset_index(drop=True) if len(df) >= 10 else df

def save_responses(results_df):
    os.makedirs("responses", exist_ok=True)
    filename = f"responses/user_responses.csv"
    if os.path.exists(filename):
        results_df.to_csv(filename, mode='a', index=False, header=False)
    else:
        results_df.to_csv(filename, index=False)

st.title("Human Evaluation Task")

st.markdown("""
### 📝 Instructions
You will be shown 10 data pairs. For each pair:
- Review the content (image and/or text).
- Assign a score between **1 (worst)** and **5 (best)** that reflects your judgment based on similarity, relevance, or appropriateness.
""")

user_id = st.text_input("Enter your name or ID (optional)", "")

data = load_data()
responses = []

for idx, row in data.iterrows():
    st.markdown(f"### Sample {idx+1}")

    col1, col2 = st.columns(2)

    with col1:
        if pd.notna(row["image_path_1"]) and row["image_path_1"]:
            st.image(row["image_path_1"], caption="Item 1", use_column_width=True)
        if pd.notna(row["text_1"]) and row["text_1"]:
            st.write(f"**Text 1:** {row['text_1']}")

    with col2:
        if pd.notna(row["image_path_2"]) and row["image_path_2"]:
            st.image(row["image_path_2"], caption="Item 2", use_column_width=True)
        if pd.notna(row["text_2"]) and row["text_2"]:
            st.write(f"**Text 2:** {row['text_2']}")

    st.write(f"**Original Model Score:** {row['model_score']}")

    score = st.slider(f"Your score for Sample {idx+1}", 1, 5, step=1, key=f"score_{idx}")
    responses.append({
        "user_id": user_id,
        "sample_id": row["id"],
        "model_score": row["model_score"],
        "user_score": score,
        "timestamp": datetime.utcnow().isoformat()
    })

if st.button("✅ Submit All"):
    results_df = pd.DataFrame(responses)
    save_responses(results_df)
    st.success("Thank you! Your responses have been recorded.")
